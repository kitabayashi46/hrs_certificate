"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.stgConfig = void 0;
exports.stgConfig = {
    envName: 'stg',
    ecs: {
        desiredCount: 1,
        cpu: 1024,
        memoryLimitMiB: 2048,
    },
    aurora: {
        minCapacity: 0.5,
        maxCapacity: 1,
        backupRetentionDays: 3,
    },
    certificateArn: 'arn:aws:acm:ap-northeast-1:682713989370:certificate/52f98171-9cce-4ffb-b5f6-e35896f29426',
    appDomainName: 'stg-chem.skysoft.jp',
    hostedZoneId: 'Z00482082KYQLMP1HAGLB',
    existingS3BucketName: 'street-light-cloud-eno',
    opsNotificationEmail: 'enomoto@skygp.co.jp',
    sesSenderDomain: 'skysoft.jp',
    webUrlJa: 'https://www.hirose.com/ja/product/login',
    webUrlEn: 'https://www.hirose.com/en/product/login',
    // ログインAPIのURL(未決定事項)。stg用の実際のエンドポイントが確定次第、実値へ差し替える
    loginApiUrl: 'http://localhost:3000/api/auth/mock-login',
    smtpFrom: 'greenmeister.support.3p@skysoft.jp',
    // SMTP認証情報のSecrets Managerシークレット名(未決定事項)。運用メモ.mdの手順で手動作成後、実値へ差し替える
    smtpCredentialSecretName: 'Chem-smtp-credential',
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2NvbmZpZy9lbnZpcm9ubWVudHMvc3RnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUVhLFFBQUEsU0FBUyxHQUFjO0lBQ2xDLE9BQU8sRUFBRSxLQUFLO0lBQ2QsR0FBRyxFQUFFO1FBQ0gsWUFBWSxFQUFFLENBQUM7UUFDZixHQUFHLEVBQUUsSUFBSTtRQUNULGNBQWMsRUFBRSxJQUFJO0tBQ3JCO0lBQ0QsTUFBTSxFQUFFO1FBQ04sV0FBVyxFQUFFLEdBQUc7UUFDaEIsV0FBVyxFQUFFLENBQUM7UUFDZCxtQkFBbUIsRUFBRSxDQUFDO0tBQ3ZCO0lBQ0QsY0FBYyxFQUFFLDBGQUEwRjtJQUMxRyxhQUFhLEVBQUUscUJBQXFCO0lBQ3BDLFlBQVksRUFBRSx1QkFBdUI7SUFDckMsb0JBQW9CLEVBQUUsd0JBQXdCO0lBQzlDLG9CQUFvQixFQUFFLHFCQUFxQjtJQUMzQyxlQUFlLEVBQUUsWUFBWTtJQUM3QixRQUFRLEVBQUUseUNBQXlDO0lBQ25ELFFBQVEsRUFBRSx5Q0FBeUM7SUFDbkQsbURBQW1EO0lBQ25ELFdBQVcsRUFBRSwyQ0FBMkM7SUFDeEQsUUFBUSxFQUFFLG9DQUFvQztJQUM5QyxtRUFBbUU7SUFDbkUsd0JBQXdCLEVBQUUsc0JBQXNCO0NBQ2pELENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFbnZDb25maWcgfSBmcm9tICcuL3R5cGVzJztcblxuZXhwb3J0IGNvbnN0IHN0Z0NvbmZpZzogRW52Q29uZmlnID0ge1xuICBlbnZOYW1lOiAnc3RnJyxcbiAgZWNzOiB7XG4gICAgZGVzaXJlZENvdW50OiAxLFxuICAgIGNwdTogMTAyNCxcbiAgICBtZW1vcnlMaW1pdE1pQjogMjA0OCxcbiAgfSxcbiAgYXVyb3JhOiB7XG4gICAgbWluQ2FwYWNpdHk6IDAuNSxcbiAgICBtYXhDYXBhY2l0eTogMSxcbiAgICBiYWNrdXBSZXRlbnRpb25EYXlzOiAzLFxuICB9LFxuICBjZXJ0aWZpY2F0ZUFybjogJ2Fybjphd3M6YWNtOmFwLW5vcnRoZWFzdC0xOjY4MjcxMzk4OTM3MDpjZXJ0aWZpY2F0ZS81MmY5ODE3MS05Y2NlLTRmZmItYjVmNi1lMzU4OTZmMjk0MjYnLFxuICBhcHBEb21haW5OYW1lOiAnc3RnLWNoZW0uc2t5c29mdC5qcCcsXG4gIGhvc3RlZFpvbmVJZDogJ1owMDQ4MjA4MktZUUxNUDFIQUdMQicsXG4gIGV4aXN0aW5nUzNCdWNrZXROYW1lOiAnc3RyZWV0LWxpZ2h0LWNsb3VkLWVubycsXG4gIG9wc05vdGlmaWNhdGlvbkVtYWlsOiAnZW5vbW90b0Bza3lncC5jby5qcCcsXG4gIHNlc1NlbmRlckRvbWFpbjogJ3NreXNvZnQuanAnLFxuICB3ZWJVcmxKYTogJ2h0dHBzOi8vd3d3Lmhpcm9zZS5jb20vamEvcHJvZHVjdC9sb2dpbicsXG4gIHdlYlVybEVuOiAnaHR0cHM6Ly93d3cuaGlyb3NlLmNvbS9lbi9wcm9kdWN0L2xvZ2luJyxcbiAgLy8g44Ot44Kw44Kk44OzQVBJ44GuVVJMKOacquaxuuWumuS6i+mghSnjgIJzdGfnlKjjga7lrp/pmpvjga7jgqjjg7Pjg4njg53jgqTjg7Pjg4jjgYznorrlrprmrKHnrKzjgIHlrp/lgKTjgbjlt67jgZfmm7/jgYjjgotcbiAgbG9naW5BcGlVcmw6ICdodHRwOi8vbG9jYWxob3N0OjMwMDAvYXBpL2F1dGgvbW9jay1sb2dpbicsXG4gIHNtdHBGcm9tOiAnZ3JlZW5tZWlzdGVyLnN1cHBvcnQuM3BAc2t5c29mdC5qcCcsXG4gIC8vIFNNVFDoqo3oqLzmg4XloLHjga5TZWNyZXRzIE1hbmFnZXLjgrfjg7zjgq/jg6zjg4Pjg4jlkI0o5pyq5rG65a6a5LqL6aCFKeOAgumBi+eUqOODoeODoi5tZOOBruaJi+mghuOBp+aJi+WLleS9nOaIkOW+jOOAgeWun+WApOOBuOW3ruOBl+abv+OBiOOCi1xuICBzbXRwQ3JlZGVudGlhbFNlY3JldE5hbWU6ICdDaGVtLXNtdHAtY3JlZGVudGlhbCcsXG59O1xuIl19