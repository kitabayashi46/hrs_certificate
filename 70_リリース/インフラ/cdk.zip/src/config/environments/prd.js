"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.prdConfig = void 0;
exports.prdConfig = {
    envName: 'prd',
    ecs: {
        desiredCount: 1,
        cpu: 1024,
        memoryLimitMiB: 2048,
    },
    aurora: {
        minCapacity: 1,
        maxCapacity: 4,
        backupRetentionDays: 3,
    },
    certificateArn: 'arn:aws:acm:ap-northeast-1:682713989370:certificate/182e9d11-fa9e-40e2-8faa-aea74a6cc583',
    appDomainName: 'chem.skysoft.jp',
    hostedZoneId: 'Z07227143FYN5KEO2UVZA',
    existingS3BucketName: 'street-light-cloud-eno',
    opsNotificationEmail: 'enomoto@skygp.co.jp',
    sesSenderDomain: 'skysoft.jp',
    webUrlJa: 'https://www.hirose.com/ja/product/login',
    webUrlEn: 'https://www.hirose.com/en/product/login',
    // ログインAPIのURL(未決定事項)。prd用の実際のエンドポイントが確定次第、実値へ差し替える
    loginApiUrl: 'http://localhost:3000/api/auth/mock-login',
    smtpFrom: 'greenmeister.support.3p@skysoft.jp',
    // SMTP認証情報のSecrets Managerシークレット名(未決定事項)。運用メモ.mdの手順で手動作成後、実値へ差し替える
    smtpCredentialSecretName: 'Chem-smtp-credential',
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2NvbmZpZy9lbnZpcm9ubWVudHMvcHJkLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUVhLFFBQUEsU0FBUyxHQUFjO0lBQ2xDLE9BQU8sRUFBRSxLQUFLO0lBQ2QsR0FBRyxFQUFFO1FBQ0gsWUFBWSxFQUFFLENBQUM7UUFDZixHQUFHLEVBQUUsSUFBSTtRQUNULGNBQWMsRUFBRSxJQUFJO0tBQ3JCO0lBQ0QsTUFBTSxFQUFFO1FBQ04sV0FBVyxFQUFFLENBQUM7UUFDZCxXQUFXLEVBQUUsQ0FBQztRQUNkLG1CQUFtQixFQUFFLENBQUM7S0FDdkI7SUFDRCxjQUFjLEVBQUUsMEZBQTBGO0lBQzFHLGFBQWEsRUFBRSxpQkFBaUI7SUFDaEMsWUFBWSxFQUFFLHVCQUF1QjtJQUNyQyxvQkFBb0IsRUFBRSx3QkFBd0I7SUFDOUMsb0JBQW9CLEVBQUUscUJBQXFCO0lBQzNDLGVBQWUsRUFBRSxZQUFZO0lBQzdCLFFBQVEsRUFBRSx5Q0FBeUM7SUFDbkQsUUFBUSxFQUFFLHlDQUF5QztJQUNuRCxtREFBbUQ7SUFDbkQsV0FBVyxFQUFFLDJDQUEyQztJQUN4RCxRQUFRLEVBQUUsb0NBQW9DO0lBQzlDLG1FQUFtRTtJQUNuRSx3QkFBd0IsRUFBRSxzQkFBc0I7Q0FDakQsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEVudkNvbmZpZyB9IGZyb20gJy4vdHlwZXMnO1xuXG5leHBvcnQgY29uc3QgcHJkQ29uZmlnOiBFbnZDb25maWcgPSB7XG4gIGVudk5hbWU6ICdwcmQnLFxuICBlY3M6IHtcbiAgICBkZXNpcmVkQ291bnQ6IDEsXG4gICAgY3B1OiAxMDI0LFxuICAgIG1lbW9yeUxpbWl0TWlCOiAyMDQ4LFxuICB9LFxuICBhdXJvcmE6IHtcbiAgICBtaW5DYXBhY2l0eTogMSxcbiAgICBtYXhDYXBhY2l0eTogNCxcbiAgICBiYWNrdXBSZXRlbnRpb25EYXlzOiAzLFxuICB9LFxuICBjZXJ0aWZpY2F0ZUFybjogJ2Fybjphd3M6YWNtOmFwLW5vcnRoZWFzdC0xOjY4MjcxMzk4OTM3MDpjZXJ0aWZpY2F0ZS8xODJlOWQxMS1mYTllLTQwZTItOGZhYS1hZWE3NGE2Y2M1ODMnLFxuICBhcHBEb21haW5OYW1lOiAnY2hlbS5za3lzb2Z0LmpwJyxcbiAgaG9zdGVkWm9uZUlkOiAnWjA3MjI3MTQzRllONUtFTzJVVlpBJyxcbiAgZXhpc3RpbmdTM0J1Y2tldE5hbWU6ICdzdHJlZXQtbGlnaHQtY2xvdWQtZW5vJyxcbiAgb3BzTm90aWZpY2F0aW9uRW1haWw6ICdlbm9tb3RvQHNreWdwLmNvLmpwJyxcbiAgc2VzU2VuZGVyRG9tYWluOiAnc2t5c29mdC5qcCcsXG4gIHdlYlVybEphOiAnaHR0cHM6Ly93d3cuaGlyb3NlLmNvbS9qYS9wcm9kdWN0L2xvZ2luJyxcbiAgd2ViVXJsRW46ICdodHRwczovL3d3dy5oaXJvc2UuY29tL2VuL3Byb2R1Y3QvbG9naW4nLFxuICAvLyDjg63jgrDjgqTjg7NBUEnjga5VUkwo5pyq5rG65a6a5LqL6aCFKeOAgnByZOeUqOOBruWun+mam+OBruOCqOODs+ODieODneOCpOODs+ODiOOBjOeiuuWumuasoeesrOOAgeWun+WApOOBuOW3ruOBl+abv+OBiOOCi1xuICBsb2dpbkFwaVVybDogJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMC9hcGkvYXV0aC9tb2NrLWxvZ2luJyxcbiAgc210cEZyb206ICdncmVlbm1laXN0ZXIuc3VwcG9ydC4zcEBza3lzb2Z0LmpwJyxcbiAgLy8gU01UUOiqjeiovOaDheWgseOBrlNlY3JldHMgTWFuYWdlcuOCt+ODvOOCr+ODrOODg+ODiOWQjSjmnKrmsbrlrprkuovpoIUp44CC6YGL55So44Oh44OiLm1k44Gu5omL6aCG44Gn5omL5YuV5L2c5oiQ5b6M44CB5a6f5YCk44G45beu44GX5pu/44GI44KLXG4gIHNtdHBDcmVkZW50aWFsU2VjcmV0TmFtZTogJ0NoZW0tc210cC1jcmVkZW50aWFsJyxcbn07XG4iXX0=